# -*- coding: utf-8 -*-
"""
Created on Tue Jul 24 15:16:53 2018

@author: Sebastian
"""

CONNECT_STATES = {1: 'DISCONNECTED', 2: 'CONNECTING', 3: 'CONNECTED',
                  4: 'DISCONNECTING', 5: 'NOT_INITIALIZED'}

BAUDRATES = [10000, 20000, 50000, 62500, 100000, 125000, 250000, 500000,
             1000000]
