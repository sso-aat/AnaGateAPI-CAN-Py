# -*- coding: utf-8 -*-
"""
Created on Mon Jul 23 21:27:10 2018

@author: Sebastian Scholz
"""

class dllException(Exception):
    pass

class CanNoMsg(Exception):
    pass

