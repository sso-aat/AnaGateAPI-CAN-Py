# AnagateCAN
AnagateCAN is a wrapped API functions adapted to be used in a pythonic way including class structure. The user only sees and gives Python build-in data types from and to the functions.
